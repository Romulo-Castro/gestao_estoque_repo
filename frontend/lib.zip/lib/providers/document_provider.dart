// frontend/lib/providers/document_provider.dart
import "package:flutter/foundation.dart";
import "/models/document_model.dart";
import "/models/document_item_model.dart";
import "/services/api_service.dart";

class DocumentProvider with ChangeNotifier {
  final ApiService _apiService;
  int? _storeId;

  List<Document> _documents = [];
  bool _isLoading = false;
  String? _error;

  List<Document> get documents => _documents;
  bool get isLoading => _isLoading;
  String? get error => _error;

  // Construtor padrão para uso com ProxyProvider
  DocumentProvider() : _apiService = ApiService(), _storeId = null;

  // Método para atualizar o token de autenticação
  void updateAuthToken(String? token) {
    _apiService.setAuthToken(token);
    debugPrint("[DocumentProvider] Token atualizado: ${token != null ? 'presente' : 'nulo'}");
  }

  // Método para definir o ID da loja atual
  void setStoreId(int? storeId) {
    if (_storeId == storeId) return;
    _storeId = storeId;
    if (storeId != null && storeId > 0) {
      fetchDocuments();
    } else {
      _documents = [];
      notifyListeners();
    }
  }

  void _setLoading(bool loading) {
    if (_isLoading == loading) return;
    _isLoading = loading;
    if (loading) _error = null;
    notifyListeners();
  }

  void _setError(String errorMsg) {
    _error = errorMsg;
    _isLoading = false;
    notifyListeners();
    debugPrint("DocumentProvider Error (Store: $_storeId): $errorMsg");
  }

  Future<void> fetchDocuments() async {
    if (_storeId == null || _storeId! <= 0) {
      _setError("ID da loja inválido para buscar documentos.");
      return;
    }
    _setLoading(true);
    try {
      // Implementação de filtros para documentos
      // Parâmetros opcionais: tipo, dataInicio, dataFim
      _documents = await _apiService.fetchDocuments(_storeId!);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _setError(e.toString());
      _documents = [];
    }
  }

  // Implementação de filtros para documentos
  Future<void> fetchDocumentsWithFilters({
    String? type,
    String? startDate,
    String? endDate,
    int? customerId,
    int? supplierId,
  }) async {
    if (_storeId == null || _storeId! <= 0) {
      _setError("ID da loja inválido para buscar documentos.");
      return;
    }
    _setLoading(true);
    try {
      _documents = await _apiService.fetchDocumentsWithFilters(
        _storeId!,
        type: type,
        startDate: startDate,
        endDate: endDate,
        customerId: customerId,
        supplierId: supplierId,
      );
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _setError(e.toString());
      _documents = [];
    }
  }

  Future<Document> fetchDocumentById(int documentId) async {
    if (_storeId == null || _storeId! <= 0) throw Exception("ID da loja inválido.");
    // Não usar _setLoading aqui para não afetar a lista principal
    try {
      final doc = await _apiService.fetchDocumentById(_storeId!, documentId);
      // Atualizar o documento na lista local se já existir?
      final index = _documents.indexWhere((d) => d.id == documentId);
      if (index != -1) {
        _documents[index] = doc; // Atualiza com os itens carregados
        notifyListeners();
      }
      return doc;
    } catch (e) {
      debugPrint("Erro ao buscar documento $documentId: $e");
      rethrow;
    }
  }

  Future<Document> createDocument(Document document) async {
    if (_storeId == null || _storeId! <= 0) throw Exception("ID da loja inválido.");
    if (document.items == null || document.items!.isEmpty) throw Exception("Documento deve ter itens.");

    _setLoading(true);
    try {
      final newDocument = await _apiService.createDocument(_storeId!, document);
      _documents.insert(0, newDocument); // Adiciona no início da lista
      _isLoading = false;
      notifyListeners();
      return newDocument;
    } catch (e) {
      _setError(e.toString());
      rethrow;
    }
  }

  // Atualizar apenas o cabeçalho (notas, data, etc.)
  Future<Document> updateDocumentHeader(int documentId, Document document) async {
    if (_storeId == null || _storeId! <= 0) throw Exception("ID da loja inválido.");
    _setLoading(true);
    try {
      final updatedDocument = await _apiService.updateDocumentHeader(
        _storeId!,
        documentId,
        document,
      );
      final index = _documents.indexWhere((d) => d.id == documentId);
      if (index != -1) {
        _documents[index] = updatedDocument;
      }
      _isLoading = false;
      notifyListeners();
      return updatedDocument;
    } catch (e) {
      _setError(e.toString());
      rethrow;
    }
  }

  // Cancelar um documento (reverte estoque)
  Future<void> cancelDocument(int documentId) async {
    if (_storeId == null || _storeId! <= 0) throw Exception("ID da loja inválido.");
    _setLoading(true);
    try {
      await _apiService.cancelDocument(_storeId!, documentId);
      // Atualizar o status do documento na lista local
      final index = _documents.indexWhere((d) => d.id == documentId);
      if (index != -1) {
        // Idealmente, a API retornaria o doc atualizado, mas podemos simular
        _documents[index] = _documents[index].copyWith(status: "CANCELADO");
      }
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _setError(e.toString());
      rethrow;
    }
  }
}
