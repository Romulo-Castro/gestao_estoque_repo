// lib/utils/app_prefs.dart
import 'package:shared_preferences/shared_preferences.dart';

/// Classe utilitária para gerenciar preferências do aplicativo
class AppPrefs {
  // Chaves para preferências
  static const String _keyFirstLaunch = 'first_launch';
  static const String _keySelectedStoreId = 'selected_store_id';
  static const String _keyGroupId = 'group_id';
  
  // Propriedades de itens
  static const String propName = 'name';
  static const String propQuantity = 'quantity';
  static const String propImage = 'image';
  static const String propCategory = 'category';
  static const String propGroupId = 'groupId';

  /// Verifica se é o primeiro lançamento do aplicativo
  static Future<bool> isFirstLaunch() async {
    final prefs = await SharedPreferences.getInstance();
    // Se a chave não existir, assume que é o primeiro lançamento
    return prefs.getBool(_keyFirstLaunch) ?? true;
  }

  /// Define que o aplicativo já foi lançado antes
  static Future<void> setFirstLaunchComplete() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyFirstLaunch, false);
  }

  /// Salva o ID da loja selecionada
  static Future<void> saveSelectedStoreId(int? storeId) async {
    final prefs = await SharedPreferences.getInstance();
    if (storeId == null) {
      await prefs.remove(_keySelectedStoreId);
    } else {
      await prefs.setInt(_keySelectedStoreId, storeId);
    }
  }

  /// Método compatível com o nome usado em StoreProvider
  static Future<void> setSelectedStoreId(int? storeId) async {
    await saveSelectedStoreId(storeId);
  }

  /// Recupera o ID da loja selecionada
  static Future<int?> getSelectedStoreId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_keySelectedStoreId);
  }

  /// Salva o ID do grupo selecionado
  static Future<void> saveGroupId(int? groupId) async {
    final prefs = await SharedPreferences.getInstance();
    if (groupId == null) {
      await prefs.remove(_keyGroupId);
    } else {
      await prefs.setInt(_keyGroupId, groupId);
    }
  }

  /// Recupera o ID do grupo selecionado
  static Future<int?> getGroupId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_keyGroupId);
  }

  /// Método para obter propriedades de itens
  static Future<List<String>> getItemProperties() async {
    return [propName, propQuantity, propImage, propCategory, propGroupId];
  }

  /// Método para obter o número de casas decimais para quantidade
  static Future<int> getQuantityDecimals() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('quantity_decimals') ?? 2;
  }

  /// Método genérico para salvar um valor booleano
  static Future<void> setBool(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
  }

  /// Método genérico para recuperar um valor booleano
  static Future<bool?> getBool(String key) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(key);
  }

  /// Método genérico para salvar uma string
  static Future<void> setString(String key, String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, value);
  }

  /// Método genérico para recuperar uma string
  static Future<String?> getString(String key) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(key);
  }

  /// Método genérico para salvar um inteiro
  static Future<void> setInt(String key, int value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(key, value);
  }

  /// Método genérico para recuperar um inteiro
  static Future<int?> getInt(String key) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(key);
  }

  /// Limpa todas as preferências
  static Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
