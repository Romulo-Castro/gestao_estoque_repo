// lib/screens/reports_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/providers/store_provider.dart';
import '/providers/stock_provider.dart';
import '/providers/document_provider.dart';
import '/widgets/app_drawer.dart';
import 'package:intl/intl.dart';
import 'dart:math' as math;

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = false;
  String _errorMessage = '';
  final DateFormat _dateFormat = DateFormat('dd/MM/yyyy');
  final NumberFormat _currencyFormat = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final storeProvider = Provider.of<StoreProvider>(context, listen: false);
    final storeId = storeProvider.selectedStoreId;
    
    if (storeId == null) {
      setState(() {
        _errorMessage = 'Selecione uma loja para visualizar os relatórios';
      });
      return;
    }
    
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });
    
    try {
      // Carrega dados necessários para os relatórios
      final stockProvider = Provider.of<StockProvider>(context, listen: false);
      final documentProvider = Provider.of<DocumentProvider>(context, listen: false);
      
      await Future.wait([
        stockProvider.fetchStockItems(storeId),
        documentProvider.fetchDocuments(storeId),
      ]);
      
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Erro ao carregar dados: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final storeProvider = Provider.of<StoreProvider>(context);
    final storeName = storeProvider.selectedStore?.name ?? 'Nenhuma loja selecionada';
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Relatórios - $storeName'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Estoque', icon: Icon(Icons.inventory_2_outlined)),
            Tab(text: 'Vendas', icon: Icon(Icons.point_of_sale_outlined)),
            Tab(text: 'Financeiro', icon: Icon(Icons.attach_money_outlined)),
          ],
        ),
      ),
      drawer: const AppDrawer(),
      body: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : _errorMessage.isNotEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, size: 48, color: Colors.red[300]),
                  const SizedBox(height: 16),
                  Text(_errorMessage, textAlign: TextAlign.center),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _loadData,
                    child: const Text('Tentar novamente'),
                  ),
                ],
              ),
            )
          : TabBarView(
              controller: _tabController,
              children: [
                _buildStockReport(),
                _buildSalesReport(),
                _buildFinancialReport(),
              ],
            ),
    );
  }

  Widget _buildStockReport() {
    final stockProvider = Provider.of<StockProvider>(context);
    final items = stockProvider.items;
    
    if (items.isEmpty) {
      return const Center(
        child: Text('Nenhum item em estoque para gerar relatório'),
      );
    }
    
    // Calcular estatísticas
    double totalValue = 0;
    int lowStockCount = 0;
    int outOfStockCount = 0;
    
    for (final item in items) {
      totalValue += (item.price ?? 0) * (item.quantity ?? 0);
      if (item.quantity != null) {
        if (item.quantity! <= 0) {
          outOfStockCount++;
        } else if (item.quantity! < 5) { // Exemplo de limite para estoque baixo
          lowStockCount++;
        }
      }
    }
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Resumo do Estoque',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Divider(),
                  _buildReportRow('Total de itens:', '${items.length}'),
                  _buildReportRow('Valor total em estoque:', _currencyFormat.format(totalValue)),
                  _buildReportRow('Itens com estoque baixo:', '$lowStockCount'),
                  _buildReportRow('Itens sem estoque:', '$outOfStockCount'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Itens com Estoque Baixo',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Card(
            elevation: 2,
            child: ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: math.min(5, items.where((item) => (item.quantity ?? 0) < 5 && (item.quantity ?? 0) > 0).length),
              itemBuilder: (ctx, index) {
                final lowStockItems = items.where((item) => (item.quantity ?? 0) < 5 && (item.quantity ?? 0) > 0).toList();
                if (index >= lowStockItems.length) return null;
                
                final item = lowStockItems[index];
                return ListTile(
                  title: Text(item.name ?? 'Sem nome'),
                  subtitle: Text('Código: ${item.sku ?? 'N/A'}'),
                  trailing: Text(
                    'Qtd: ${item.quantity}',
                    style: TextStyle(
                      color: (item.quantity ?? 0) < 3 ? Colors.red : Colors.orange,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Itens Mais Valiosos',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Card(
            elevation: 2,
            child: ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: math.min(5, items.length),
              itemBuilder: (ctx, index) {
                final sortedItems = List.from(items)
                  ..sort((a, b) => ((b.price ?? 0) * (b.quantity ?? 0))
                      .compareTo((a.price ?? 0) * (a.quantity ?? 0)));
                
                if (index >= sortedItems.length) return null;
                
                final item = sortedItems[index];
                final itemValue = (item.price ?? 0) * (item.quantity ?? 0);
                
                return ListTile(
                  title: Text(item.name ?? 'Sem nome'),
                  subtitle: Text('Qtd: ${item.quantity} × ${_currencyFormat.format(item.price ?? 0)}'),
                  trailing: Text(
                    _currencyFormat.format(itemValue),
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSalesReport() {
    final documentProvider = Provider.of<DocumentProvider>(context);
    final documents = documentProvider.documents.where((doc) => doc.type == 'SAIDA').toList();
    
    if (documents.isEmpty) {
      return const Center(
        child: Text('Nenhuma venda registrada para gerar relatório'),
      );
    }
    
    // Calcular estatísticas
    double totalSales = 0;
    final today = DateTime.now();
    final startOfMonth = DateTime(today.year, today.month, 1);
    double monthlySales = 0;
    
    for (final doc in documents) {
      final docDate = doc.date != null ? DateTime.parse(doc.date!) : null;
      final docTotal = doc.items?.fold<double>(0, (sum, item) => sum + (item.quantity * item.price)) ?? 0;
      
      totalSales += docTotal;
      
      if (docDate != null && docDate.isAfter(startOfMonth)) {
        monthlySales += docTotal;
      }
    }
    
    // Agrupar vendas por mês para o gráfico
    final Map<String, double> salesByMonth = {};
    for (final doc in documents) {
      if (doc.date != null) {
        final docDate = DateTime.parse(doc.date!);
        final monthKey = '${docDate.month}/${docDate.year}';
        final docTotal = doc.items?.fold<double>(0, (sum, item) => sum + (item.quantity * item.price)) ?? 0;
        
        salesByMonth[monthKey] = (salesByMonth[monthKey] ?? 0) + docTotal;
      }
    }
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Resumo de Vendas',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Divider(),
                  _buildReportRow('Total de vendas:', '${documents.length}'),
                  _buildReportRow('Valor total vendido:', _currencyFormat.format(totalSales)),
                  _buildReportRow('Vendas do mês atual:', _currencyFormat.format(monthlySales)),
                  _buildReportRow('Ticket médio:', _currencyFormat.format(documents.isNotEmpty ? totalSales / documents.length : 0)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Últimas Vendas',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Card(
            elevation: 2,
            child: ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: math.min(5, documents.length),
              itemBuilder: (ctx, index) {
                final sortedDocs = List.from(documents)
                  ..sort((a, b) => (b.date ?? '').compareTo(a.date ?? ''));
                
                if (index >= sortedDocs.length) return null;
                
                final doc = sortedDocs[index];
                final docTotal = doc.items?.fold<double>(0, (sum, item) => sum + (item.quantity * item.price)) ?? 0;
                final docDate = doc.date != null ? _dateFormat.format(DateTime.parse(doc.date!)) : 'Data desconhecida';
                
                return ListTile(
                  title: Text('Venda #${doc.id}'),
                  subtitle: Text('Data: $docDate'),
                  trailing: Text(
                    _currencyFormat.format(docTotal),
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Maiores Vendas',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Card(
            elevation: 2,
            child: ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: math.min(5, documents.length),
              itemBuilder: (ctx, index) {
                final sortedDocs = List.from(documents)
                  ..sort((a, b) {
                    final totalA = a.items?.fold<double>(0, (sum, item) => sum + (item.quantity * item.price)) ?? 0;
                    final totalB = b.items?.fold<double>(0, (sum, item) => sum + (item.quantity * item.price)) ?? 0;
                    return totalB.compareTo(totalA);
                  });
                
                if (index >= sortedDocs.length) return null;
                
                final doc = sortedDocs[index];
                final docTotal = doc.items?.fold<double>(0, (sum, item) => sum + (item.quantity * item.price)) ?? 0;
                final docDate = doc.date != null ? _dateFormat.format(DateTime.parse(doc.date!)) : 'Data desconhecida';
                
                return ListTile(
                  title: Text('Venda #${doc.id}'),
                  subtitle: Text('Data: $docDate'),
                  trailing: Text(
                    _currencyFormat.format(docTotal),
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFinancialReport() {
    final documentProvider = Provider.of<DocumentProvider>(context);
    final salesDocs = documentProvider.documents.where((doc) => doc.type == 'SAIDA').toList();
    final purchaseDocs = documentProvider.documents.where((doc) => doc.type == 'ENTRADA').toList();
    
    // Calcular estatísticas
    double totalSales = 0;
    double totalPurchases = 0;
    
    for (final doc in salesDocs) {
      totalSales += doc.items?.fold<double>(0, (sum, item) => sum + (item.quantity * item.price)) ?? 0;
    }
    
    for (final doc in purchaseDocs) {
      totalPurchases += doc.items?.fold<double>(0, (sum, item) => sum + (item.quantity * item.price)) ?? 0;
    }
    
    final profit = totalSales - totalPurchases;
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Resumo Financeiro',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Divider(),
                  _buildReportRow('Receita total (vendas):', _currencyFormat.format(totalSales)),
                  _buildReportRow('Despesa total (compras):', _currencyFormat.format(totalPurchases)),
                  const Divider(),
                  _buildReportRow(
                    'Lucro bruto:',
                    _currencyFormat.format(profit),
                    valueColor: profit >= 0 ? Colors.green : Colors.red,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Últimas Entradas',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Card(
            elevation: 2,
            child: purchaseDocs.isEmpty
                ? const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text('Nenhuma entrada registrada'),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: math.min(5, purchaseDocs.length),
                    itemBuilder: (ctx, index) {
                      final sortedDocs = List.from(purchaseDocs)
                        ..sort((a, b) => (b.date ?? '').compareTo(a.date ?? ''));
                      
                      if (index >= sortedDocs.length) return null;
                      
                      final doc = sortedDocs[index];
                      final docTotal = doc.items?.fold<double>(0, (sum, item) => sum + (item.quantity * item.price)) ?? 0;
                      final docDate = doc.date != null ? _dateFormat.format(DateTime.parse(doc.date!)) : 'Data desconhecida';
                      
                      return ListTile(
                        title: Text('Entrada #${doc.id}'),
                        subtitle: Text('Data: $docDate'),
                        trailing: Text(
                          _currencyFormat.format(docTotal),
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.red,
                          ),
                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Produtos Mais Rentáveis',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Card(
            elevation: 2,
            child: salesDocs.isEmpty
                ? const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text('Nenhuma venda registrada para análise'),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: 5,
                    itemBuilder: (ctx, index) {
                      // Aqui seria necessário um cálculo mais complexo para determinar
                      // os produtos mais rentáveis, considerando margem de lucro
                      // Por simplicidade, mostramos os produtos mais vendidos
                      
                      // Agrupar itens vendidos
                      final Map<String, double> salesByProduct = {};
                      for (final doc in salesDocs) {
                        for (final item in doc.items ?? []) {
                          final productName = item.itemName ?? 'Produto sem nome';
                          salesByProduct[productName] = (salesByProduct[productName] ?? 0) + (item.quantity * item.price);
                        }
                      }
                      
                      final sortedProducts = salesByProduct.entries.toList()
                        ..sort((a, b) => b.value.compareTo(a.value));
                      
                      if (index >= sortedProducts.length) return null;
                      
                      final entry = sortedProducts[index];
                      
                      return ListTile(
                        title: Text(entry.key),
                        trailing: Text(
                          _currencyFormat.format(entry.value),
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildReportRow(String label, String value, {Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 16)),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }
}
