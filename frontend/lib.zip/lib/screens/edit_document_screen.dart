// frontend/lib/screens/edit_document_screen.dart
import "package:flutter/material.dart";
import "package:intl/intl.dart";
import "package:provider/provider.dart";
import "/models/document_model.dart";
import "/models/document_item_model.dart";
import "/models/stock_item.dart";
import "/models/customer_model.dart";
import "/models/supplier_model.dart";
import "/providers/document_provider.dart";
import "/providers/stock_provider.dart";
import "/providers/customer_provider.dart";
import "/providers/supplier_provider.dart";
import "/providers/store_provider.dart";

class EditDocumentScreen extends StatefulWidget {
  const EditDocumentScreen({super.key});

  @override
  State<EditDocumentScreen> createState() => _EditDocumentScreenState();
}

class _EditDocumentScreenState extends State<EditDocumentScreen> {
  final _formKey = GlobalKey<FormState>();
  DocumentType _selectedType = DocumentType.ENTRADA;
  DateTime _selectedDate = DateTime.now();
  Customer? _selectedCustomer;
  Supplier? _selectedSupplier;
  final _notesController = TextEditingController();

  final List<DocumentItem> _items = [];
  bool _isLoading = false;
  bool _isSaving = false;

  StockItem? _selectedStockItem;
  final _quantityController = TextEditingController(text: "1");
  final _priceController = TextEditingController(text: "0.00");

  final _addItemFormKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    final storeId = Provider.of<StoreProvider>(context, listen: false).selectedStoreId;
    if (storeId != null) {
      _loadInitialData(storeId);
    }
  }

  Future<void> _loadInitialData(int storeId) async {
    setState(() => _isLoading = true);
    try {
      // Carregar dados em paralelo
      await Future.wait([
        Provider.of<StockProvider>(context, listen: false).fetchStockItems(),
        Provider.of<CustomerProvider>(context, listen: false).fetchCustomers(),
        Provider.of<SupplierProvider>(context, listen: false).fetchSuppliers(),
      ]);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Erro ao carregar dados iniciais: $e"), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  void dispose() {
    _notesController.dispose();
    _quantityController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  void _presentDatePicker() {
    showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    ).then((pickedDate) {
      if (pickedDate == null) {
        return;
      }
      setState(() {
        _selectedDate = pickedDate;
      });
    });
  }

  void _addItemToList() {
    if (!_addItemFormKey.currentState!.validate()) {
      return;
    }
    if (_selectedStockItem == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Selecione um item."), backgroundColor: Colors.orange),
      );
      return;
    }

    final quantity = double.tryParse(_quantityController.text);
    final price = double.tryParse(_priceController.text);

    if (quantity == null || quantity <= 0) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Quantidade inválida."), backgroundColor: Colors.orange),
      );
      return;
    }
     if (price == null || price < 0) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Preço inválido."), backgroundColor: Colors.orange),
      );
      return;
    }

    if (_items.any((item) => item.itemId == _selectedStockItem!.id)) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Item já adicionado."), backgroundColor: Colors.orange),
      );
      return;
    }

    setState(() {
      _items.add(DocumentItem(
        id: 0,
        documentId: 0,
        itemId: _selectedStockItem!.id,
        itemName: _selectedStockItem!.name,
        quantity: quantity,
        price: price,
      ));
      _selectedStockItem = null;
      _quantityController.text = "1";
      _priceController.text = "0.00";
    });
     FocusScope.of(context).unfocus();
  }

  void _removeItem(int index) {
    setState(() {
      _items.removeAt(index);
    });
  }

  Future<void> _saveDocument() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    if (_items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Adicione pelo menos um item ao documento."), backgroundColor: Colors.orange),
      );
      return;
    }

    if (_selectedType == DocumentType.SAIDA && _selectedCustomer == null) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Selecione um cliente para documentos de saída."), backgroundColor: Colors.orange),
      );
      return;
    }
    if (_selectedType == DocumentType.ENTRADA && _selectedSupplier == null) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Selecione um fornecedor para documentos de entrada."), backgroundColor: Colors.orange),
      );
      return;
    }

    _formKey.currentState!.save();
    setState(() => _isSaving = true);

    final docProvider = Provider.of<DocumentProvider>(context, listen: false);
    final formattedDate = DateFormat("yyyy-MM-dd").format(_selectedDate);
    final storeId = Provider.of<StoreProvider>(context, listen: false).selectedStoreId!;

    try {
      // Criar documento com todos os dados necessários
      final document = Document(
        id: 0,
        storeId: storeId,
        type: _selectedType,
        date: formattedDate,
        customerId: _selectedCustomer?.id,
        supplierId: _selectedSupplier?.id,
        notes: _notesController.text.isEmpty ? null : _notesController.text,
        status: "ABERTO",
        createdAt: "",
        updatedAt: "",
        items: _items,
      );
      
      await docProvider.createDocument(document);
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Documento criado com sucesso!"), backgroundColor: Colors.green),
      );
      Navigator.of(context).pop();
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Erro ao criar documento: $error"), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final storeId = context.watch<StoreProvider>().selectedStoreId;
    final stockProvider = context.watch<StockProvider>();
    final customerProvider = context.watch<CustomerProvider>();
    final supplierProvider = context.watch<SupplierProvider>();

    if (storeId == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text("Loja não selecionada.")));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Criar Documento"),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _isSaving ? null : _saveDocument,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _isSaving
              ? const Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Colors.green)))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16.0),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        // --- Cabeçalho do Documento ---
                        DropdownButtonFormField<DocumentType>(
                          value: _selectedType,
                          decoration: const InputDecoration(labelText: "Tipo de Documento*"),
                          items: DocumentType.values
                              .where((t) => t != DocumentType.UNKNOWN)
                              .map((type) => DropdownMenuItem(
                                    value: type,
                                    child: Text(documentTypeToString(type)),
                                  ))
                              .toList(),
                          onChanged: (value) {
                            if (value != null) {
                              setState(() {
                                _selectedType = value;
                                if (_selectedType != DocumentType.SAIDA) _selectedCustomer = null;
                                if (_selectedType != DocumentType.ENTRADA) _selectedSupplier = null;
                              });
                            }
                          },
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                "Data: ${DateFormat("dd/MM/yyyy").format(_selectedDate)}",
                              ),
                            ),
                            TextButton.icon(
                              icon: const Icon(Icons.calendar_today),
                              label: const Text("Selecionar Data"),
                              onPressed: _presentDatePicker,
                            ),
                          ],
                        ),
                        // Mostrar dropdown de Cliente apenas para SAIDA
                        if (_selectedType == DocumentType.SAIDA)
                          DropdownButtonFormField<Customer>(
                            value: _selectedCustomer,
                            decoration: const InputDecoration(labelText: "Cliente*"),
                            items: customerProvider.customers
                                .map((c) => DropdownMenuItem(
                                      value: c,
                                      child: Text(c.name),
                                    ))
                                .toList(),
                            onChanged: (value) => setState(() => _selectedCustomer = value),
                            validator: (value) => value == null ? "Selecione um cliente" : null,
                          ),
                        // Mostrar dropdown de Fornecedor apenas para ENTRADA
                        if (_selectedType == DocumentType.ENTRADA)
                          DropdownButtonFormField<Supplier>(
                            value: _selectedSupplier,
                            decoration: const InputDecoration(labelText: "Fornecedor*"),
                            items: supplierProvider.suppliers
                                .map((s) => DropdownMenuItem(
                                      value: s,
                                      child: Text(s.name),
                                    ))
                                .toList(),
                            onChanged: (value) => setState(() => _selectedSupplier = value),
                             validator: (value) => value == null ? "Selecione um fornecedor" : null,
                          ),
                        TextFormField(
                          controller: _notesController,
                          decoration: const InputDecoration(labelText: "Observações"),
                          keyboardType: TextInputType.multiline,
                          maxLines: 2,
                        ),
                        const SizedBox(height: 20),
                        const Divider(),
                        const SizedBox(height: 10),
                        Text("Itens do Documento", style: Theme.of(context).textTheme.titleLarge),
                        const SizedBox(height: 10),

                        // --- Formulário para Adicionar Item ---
                        Card(
                          elevation: 2,
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Form(
                              key: _addItemFormKey,
                              child: Column(
                                children: [
                                  // Dropdown para selecionar item de estoque
                                  DropdownButtonFormField<StockItem>(
                                    value: _selectedStockItem,
                                    hint: const Text("Selecione um item..."),
                                    isExpanded: true,
                                    items: stockProvider.items
                                        .map((item) => DropdownMenuItem(
                                              value: item,
                                              child: Text("${item.name} (Disp: ${item.quantity})"),
                                            ))
                                        .toList(),
                                    onChanged: (value) => setState(() => _selectedStockItem = value),
                                    validator: (value) => value == null ? "Selecione um item" : null,
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    children: [
                                      Expanded(
                                        flex: 2,
                                        child: TextFormField(
                                          controller: _quantityController,
                                          decoration: const InputDecoration(labelText: "Qtd*", hintText: "1"),
                                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                          validator: (value) {
                                            if (value == null || value.isEmpty) return "Obrigatório";
                                            final qty = double.tryParse(value);
                                            if (qty == null || qty <= 0) return "Inválido";
                                            return null;
                                          },
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        flex: 3,
                                        child: TextFormField(
                                          controller: _priceController,
                                          decoration: const InputDecoration(labelText: "Preço*", hintText: "0.00"),
                                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                          validator: (value) {
                                            if (value == null || value.isEmpty) return "Obrigatório";
                                            final price = double.tryParse(value);
                                            if (price == null || price < 0) return "Inválido";
                                            return null;
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 12),
                                  ElevatedButton.icon(
                                    icon: const Icon(Icons.add),
                                    label: const Text("Adicionar Item"),
                                    onPressed: _addItemToList,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),

                        // --- Lista de Itens Adicionados ---
                        const SizedBox(height: 16),
                        Text("Itens Adicionados (${_items.length})", style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 8),
                        if (_items.isEmpty)
                          const Card(
                            child: Padding(
                              padding: EdgeInsets.all(16.0),
                              child: Text("Nenhum item adicionado ainda."),
                            ),
                          )
                        else
                          ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: _items.length,
                            itemBuilder: (ctx, index) {
                              final item = _items[index];
                              final stockItem = stockProvider.items.firstWhere(
                                (si) => si.id == item.itemId, 
                                orElse: () => StockItem(
                                  id: item.itemId, 
                                  storeId: storeId, 
                                  name: item.itemName ?? "Item Desconhecido", 
                                  quantity: 0, 
                                  properties: {},
                                  createdAt: "", 
                                  updatedAt: ""
                                )
                              );
                              
                              return Card(
                                margin: const EdgeInsets.symmetric(vertical: 4),
                                child: ListTile(
                                  title: Text(stockItem.name),
                                  subtitle: Text("Qtd: ${item.quantity} × R\$ ${item.price?.toStringAsFixed(2) ?? '0.00'}"),
                                  trailing: IconButton(
                                    icon: const Icon(Icons.delete, color: Colors.red),
                                    onPressed: () => _removeItem(index),
                                  ),
                                ),
                              );
                            },
                          ),

                        const SizedBox(height: 32),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.save),
                          label: const Text("Salvar Documento"),
                          style: ElevatedButton.styleFrom(
                            minimumSize: const Size.fromHeight(50),
                          ),
                          onPressed: _isSaving ? null : _saveDocument,
                        ),
                      ],
                    ),
                  ),
                ),
    );
  }
}
